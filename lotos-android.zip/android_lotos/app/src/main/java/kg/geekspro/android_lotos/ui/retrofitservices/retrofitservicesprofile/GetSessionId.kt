package kg.geekspro.android_lotos.ui.retrofitservices.retrofitservicesprofile

import okhttp3.MediaType
import okhttp3.OkHttpClient
import okhttp3.RequestBody

class GetSessionId {
    val client = OkHttpClient()

    //val requestBody = RequestBody.create(MediaType.parse("application/json"),)
}