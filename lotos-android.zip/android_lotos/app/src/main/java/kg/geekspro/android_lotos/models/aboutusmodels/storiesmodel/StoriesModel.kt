package kg.geekspro.android_lotos.models.aboutusmodels.storiesmodel

data class StoriesModel(
    val image: Int,
    val title: String,
    val descriptor: String?
)
