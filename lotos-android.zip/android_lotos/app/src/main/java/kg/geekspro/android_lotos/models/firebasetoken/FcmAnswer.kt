package kg.geekspro.android_lotos.models.firebasetoken

data class FcmAnswer(
    val fcm_token:String,
)