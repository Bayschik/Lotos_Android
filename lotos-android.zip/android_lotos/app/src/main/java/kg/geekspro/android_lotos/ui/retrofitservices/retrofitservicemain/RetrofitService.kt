package kg.geekspro.android_lotos.ui.retrofitservices.retrofitservicemain

object RetrofitService {
    //
}