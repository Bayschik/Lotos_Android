package kg.geekspro.android_lotos.ui.fragments.mainfragments

interface OnTotalPriceChangedListener {
    fun onTotalPriceChanged(totalPrice: Int)
}
