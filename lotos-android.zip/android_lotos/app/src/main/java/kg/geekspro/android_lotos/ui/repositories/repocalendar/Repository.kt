package kg.geekspro.android_lotos.ui.repositories.repocalendar

class Repository {
}