package kg.geekspro.android_lotos.ui.fragments.profile.logOut


import com.google.gson.annotations.SerializedName


data class LogOutMessage(
    @SerializedName("message")
    val message: String
)