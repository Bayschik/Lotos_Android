package kg.geekspro.android_lotos.ui.fragments.profile

data class Token(
    val token:String?=null
)