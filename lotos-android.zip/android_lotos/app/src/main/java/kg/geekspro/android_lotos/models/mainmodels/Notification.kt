package kg.geekspro.android_lotos.models.mainmodels

import java.io.Serializable

data class Notification (
    val title:String,
    val desc:String,
    val createdAt:String,
    val createdTime:String
)