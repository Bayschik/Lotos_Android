package kg.geekspro.android_lotos.models.safetymodel.safetypassword

data class SafetyPassword(
    val id: String
)
