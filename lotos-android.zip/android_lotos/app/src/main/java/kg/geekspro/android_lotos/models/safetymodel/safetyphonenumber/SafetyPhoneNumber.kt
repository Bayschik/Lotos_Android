package kg.geekspro.android_lotos.models.safetymodel.safetyphonenumber

data class SafetyPhoneNumber(
    val id: String

)
