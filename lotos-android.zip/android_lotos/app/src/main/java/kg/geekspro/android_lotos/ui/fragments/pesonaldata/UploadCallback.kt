package kg.geekspro.android_lotos.ui.fragments.pesonaldata

interface UploadCallback {
    fun onProgressUpdate(percentage:Int)
}