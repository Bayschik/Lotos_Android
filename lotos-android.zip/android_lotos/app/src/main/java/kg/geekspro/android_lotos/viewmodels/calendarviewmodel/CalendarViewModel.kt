package kg.geekspro.android_lotos.viewmodels.calendarviewmodel

class CalendarViewModel {
}