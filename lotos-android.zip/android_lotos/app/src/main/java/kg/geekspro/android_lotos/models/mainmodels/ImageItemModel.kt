package kg.geekspro.android_lotos.models.mainmodels

data class ImageItemModel(
    val id : String,
    val url : String
)
