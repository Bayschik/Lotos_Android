package kg.geekspro.android_lotos.ui.prefs.prefcalendar

class Pref {
}