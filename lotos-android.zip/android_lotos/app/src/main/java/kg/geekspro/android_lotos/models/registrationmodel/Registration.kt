package kg.geekspro.android_lotos.models.registrationmodel

data class Registration(
    val email:String
)
