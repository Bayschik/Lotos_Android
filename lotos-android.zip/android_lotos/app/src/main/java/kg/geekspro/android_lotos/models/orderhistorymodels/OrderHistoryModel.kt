package kg.geekspro.android_lotos.models.orderhistorymodels

data class OrderHistoryModel(
    val date:String,
    val typeOfCleaning:String,
    val homeAddress:String,
    val status:String
)
