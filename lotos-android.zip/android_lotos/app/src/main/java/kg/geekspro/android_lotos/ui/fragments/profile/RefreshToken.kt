package kg.geekspro.android_lotos.ui.fragments.profile

data class RefreshToken(
    val refresh:String
)