package kg.geekspro.android_lotos.models.aboutusmodels.contactsmodels

data class WhatsAppModel(
    val id: Int,
    val title:String,
    val url:String,
)
