package kg.geekspro.android_lotos.models.safetymodel.safetyemailaddress

data class EmailAddress(
    val id: String
)
