package kg.geekspro.android_lotos.models.mainmodels

data class ResultsModel(
    val id:Int,
    val title:String,
    val image:String,
    val one_room:String,
)