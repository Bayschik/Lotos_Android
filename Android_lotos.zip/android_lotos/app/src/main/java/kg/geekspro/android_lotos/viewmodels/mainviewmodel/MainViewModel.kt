package kg.geekspro.android_lotos.viewmodels.mainviewmodel

class MainViewModel {

}