package kg.geekspro.android_lotos.ui.adapters.safetyadapter

class Safety {
    //
}