package kg.geekspro.android_lotos.models.verifycode

data class VerificationCode(
    val code:String
)
