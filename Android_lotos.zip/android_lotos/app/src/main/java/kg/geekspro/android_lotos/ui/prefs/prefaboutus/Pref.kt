package kg.geekspro.android_lotos.ui.prefs.prefaboutus

class Pref() {
    //
}