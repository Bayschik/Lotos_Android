package kg.geekspro.android_lotos.ui.retrofitservices.retrofitservicecalendar

object RetrofitService {
    //
}