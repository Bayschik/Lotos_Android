package kg.geekspro.android_lotos.models.onboarding

data class OnBoarding(
    val image:Int,
    val title:String
)
