package kg.geekspro.android_lotos.ui.fragments.safety.safetyEmail

data class Code(
    val code:String
)
