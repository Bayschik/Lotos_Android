package kg.geekspro.android_lotos.ui.prefs.prefmain

class Pref() {
    //
}