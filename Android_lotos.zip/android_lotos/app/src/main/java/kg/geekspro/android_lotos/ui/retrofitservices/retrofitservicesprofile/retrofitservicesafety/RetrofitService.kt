package kg.geekspro.android_lotos.ui.retrofitservices.retrofitservicesprofile.retrofitservicesafety

object RetrofitService {
    //
}