package kg.geekspro.android_lotos.ui.retrofitservices.retrofitserviceaboutus

object RetrofitService {
    //
}