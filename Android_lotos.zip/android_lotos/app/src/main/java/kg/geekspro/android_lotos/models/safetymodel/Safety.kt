package kg.geekspro.android_lotos.models.safetymodel

data class Safety(
    val id : String,
    //val url : String это я просто так создал, потом по таску своему можете поменять
)
