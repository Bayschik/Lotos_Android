package kg.geekspro.android_lotos.models.aboutusmodels.youtubemodel

data class Result1(
    val id: Int,
    val title: String,
    val url: String,
    val created_at: String,
)

