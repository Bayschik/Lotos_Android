package kg.geekspro.android_lotos.ui.repositories.repomain

class Repository {
    //
}