package kg.geekspro.android_lotos.ui.interfaces.maininterfeces

interface ApiService {
    //
}