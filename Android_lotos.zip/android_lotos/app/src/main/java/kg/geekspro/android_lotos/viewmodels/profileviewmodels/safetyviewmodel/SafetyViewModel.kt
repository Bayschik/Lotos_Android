package kg.geekspro.android_lotos.viewmodels.profileviewmodels.safetyviewmodel

class SafetyViewModel {
    //
}