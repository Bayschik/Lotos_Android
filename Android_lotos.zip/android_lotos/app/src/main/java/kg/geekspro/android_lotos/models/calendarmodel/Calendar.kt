package kg.geekspro.android_lotos.models.calendarmodel

data class Calendar(
    val id : String,
    //val url : String это я просто так создал, потом по таску своему можете поменять
)
