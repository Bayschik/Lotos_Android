package kg.geekspro.android_lotos.ui.fragments.login

data class LogIn(
    val email:String,
    val password:String
)
