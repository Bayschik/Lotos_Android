package kg.geekspro.android_lotos.ui.fragments.safety.safetyEmail

data class ChangeEmail(
    val email:String
)
