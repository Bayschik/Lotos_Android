package kg.geekspro.android_lotos.ui.prefs.prefsprofile.prefsafety

class PrefSafety {
    // 
}