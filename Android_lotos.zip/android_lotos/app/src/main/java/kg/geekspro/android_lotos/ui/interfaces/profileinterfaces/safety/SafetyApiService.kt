package kg.geekspro.android_lotos.ui.interfaces.profileinterfaces.safety

interface SafetyApiService {
    //
}